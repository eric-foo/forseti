# Demand Search-Interest + Answer-Engine (AEO) Sourcing & Gate-Read Delta Spec v0

```yaml
retrieval_header_version: 1
artifact_role: Product-method spec (PROPOSED — search-interest + answer-engine (AEO) demand-signal sourcing + demand-gate read-delta). Consumes the durability capture machinery; does not fork it. Not doctrine, not validation, not readiness.
scope: >
  Settles search-interest and answer-engine (AEO) visibility as demand-channel
  signals for Orca's demand spine: the source surfaces, the demand-gate read
  delta, the core/satellite architecture (two decision products, one wall), the
  feasibility gate, and the owner-gated sourcing ask. Primary engine = Google AI
  Overviews; secondary = Gemini + ChatGPT. First target sub-niche = US indie/DTC
  fragrance. Docs-first; no scrape execution; sourcing owner-gated (AR-04).
use_when:
  - Settling search-interest / AEO sourcing + the gate-read delta before any capture is authorized.
  - Checking the core/satellite wall (which seed may feed the blind gate).
authority_boundary: retrieval_only
open_next:
  - docs/product/data_capture_spine/demand_durability_indicator_search_interest_capture_profile_v0.md  # CONSUME (durability-use search-interest profile) — do not fork
  - docs/product/data_capture_spine/capture_envelope_durability_delta_spec_v0.md                       # CONSUME (temporal regimes, cold-start, comparability)
  - docs/product/data_capture_spine/core_spine_v0_data_capture_spine_obligation_contract_v0.md         # CONSUME (capture envelope of record / obligations)
  - docs/product/product_lead/orca_buyer_proof_packet_v0.md                                            # the live Demand-Substrate Hard Gate (G1 cards, AR-04, floor/ceiling, defeater)
  - docs/product/core_spine/orca_demand_scan_core_spec_v0.md                                           # candidate-observation schema (gate-family field)
  - docs/product/product_lead/orca_demand_gate_definition_closures_proposal_v0.md                      # AR-04 unsourced-gap classification
  - docs/product/data_capture_spine/data_capture_source_access_boundary_decision_v0.md                 # access/ToS posture (capture-spine-owned)
stale_if:
  - The capture envelope of record (obligation contract / models.py) is amended in a way that covers these facts.
  - An owner decision adopts/narrows/rejects the search-interest or AEO sourcing classification.
  - Phase 0 finds the AI-Overview observation infeasible/non-automatable (re-route AEO-primary).
```

- Status: `PROPOSED_PENDING_FEASIBILITY_AND_OWNER_ADJUDICATION`
- Implementation / runtime / contract-hardening authorized: **no**
- Sourcing authorized: **no** — owner-gated (AR-04)
- First target sub-niche: **US indie/DTC fragrance** (owner-set 2026-06-17; narrows the beauty/personal-care class for the first run; does not override the separate sub-niche-selection lane)
- Engine order: **Google AI Overviews (primary)** → Gemini, ChatGPT (secondary) → others out of scope for now

## Consume-not-fork ledger (pins = sha256 first-16-hex, origin/main @ ada92695)

| Source | Pin | Relation |
| --- | --- | --- |
| `demand_durability_indicator_search_interest_capture_profile_v0.md` | `58afed8650dfc53d` | CONSUME — durability-use capture obligations, temporal regimes, cold-start, comparability. This spec adds the **gate-read delta**, not a second capture profile. |
| `capture_envelope_durability_delta_spec_v0.md` | `afe3156a32dea4b8` | CONSUME — temporal regimes / cold-start / comparability. |
| `core_spine_v0_data_capture_spine_obligation_contract_v0.md` | `82ff4d7517bcfd5b` | CONSUME — envelope of record; if conflict, it wins. |
| `orca_buyer_proof_packet_v0.md` | `d4308e066e452324` | the live Demand-Substrate Hard Gate (G1 cards, AR-04, floor/ceiling, defeater). |
| `orca_demand_scan_core_spec_v0.md` | `77533f6c13eb674b` | candidate-observation schema (per-observation gate-family field). |
| `orca_demand_gate_definition_closures_proposal_v0.md` | `69da636721646565` | AR-04 (search-interest = G1 unsourced demand-family gap, owner-owned). |
| `data_capture_source_access_boundary_decision_v0.md` | `4f9dd359077bf9e1` | access/ToS posture (cite, never set). |

## 1. Purpose & what this settles

Search-interest is an **AR-04 G1 unsourced demand-family gap** — agreed-on, not
yet sourced. This spec settles it (and the adjacent answer-engine surface) for
the demand spine: which surfaces, how each reads, the gate-read delta, the
core/satellite wall, the feasibility gate, and the owner-gated sourcing ask. It
**consumes** the existing durability search-interest capture machinery and adds
only the gate-admission delta; it does not re-derive or fork capture obligations.

## 2. Two decision products, one wall

Orca sells *decisions*, not only demand-existence verdicts. Two distinct
decisions sit on these signals — keep their **inputs** walled, not their value:

- **Decision A — demand existence** (the gate's job): *does independent demand
  exist, and how bold a bet does it license?* Inputs must be **blind /
  independent**. Fed by the **Core**.
- **Decision B — channel position** (the AEO/GTM job): *given demand exists, am I
  winning the AI-answer channel for it, and should I invest there?* Inputs may be
  **first-party-seeded** (you are advising on the brand's own channel). Fed by the
  **Satellite**.

Both are first-class Orca outputs. The wall (Section 6) keeps Decision B's
first-party inputs out of Decision A's blind read — not because B is lesser, but
because mixing them would make A circular.

## 3. Signal model — attention-class reads; floor/ceiling rule

Both reads are **attention/visibility-class**:

- **Search-interest** — humans actively searching = interest-class demand-family signal.
- **Answer-engine (AEO) visibility** — what AI answers surface to humans = visibility-class.

Shared rule (consumed from the gate): a **mention / interest signal caps the
CEILING** (how bold); only **costly behavior (a conversion/payment/switch)
clears the FLOOR** (is there real demand at all). **Neither search-interest nor
AEO-surfacing can clear the floor by itself.** A captured conversion is read as
costly behavior under the existing gate rule, not under this spec.

## 4. Source surfaces + evaluation

Each surface is specified on: read supported (interest vs costly behavior) ·
provenance + retrieval-date · coverage/granularity (US, term, time) ·
comparability/normalization · manipulability + how kept gradeable · access/ToS
feasibility · decay/freshness (max capture-to-use age for a live 30–90-day read).

**Search-interest surfaces**
- **Google Trends** — relative interest over time/term/geo; normalized (0–100), not absolute volume; good comparability across terms; US geo; cheap, low-ToS-risk.
- **A search-volume source** — absolute-ish volume estimates (term-level); coverage/accuracy varies by provider; pin the provider + method in capture.
- **Marketplace / on-site search** — category-platform search signals (where obtainable); closest to purchase-intent search; access/ToS-sensitive.

**Answer-engine (AEO) visibility surfaces** (multi-engine; "shown vs not-shown" is a state, not absence-of-demand)
- **Google AI Overviews — PRIMARY.** Zero-click answer inside Google SERP → rides Google's query volume → the broadest real-exposure surface. Capture: surfaced brands/products + cited sources + (where visible) the queries it issues, dated, US, logged-out, fixed method. Caveats: high volatility/personalization, uneven coverage (Overviews don't fire for all queries — record "not shown" explicitly), observation fragility + ToS.
- **Gemini, ChatGPT — SECONDARY** (the two biggest chat platforms). Same capture shape; backfill AI-Overview coverage gaps and cross-check.
- **LLM-issued queries (query-discovery only).** The Google queries an engine fires when seeded — a **term-expansion aid**, **never demand evidence**; may feed item-5 seeding, never the gate.

## 5. Google → engine seeding proxy

We cannot see engine query *volumes*. So: **seed the engine probes from top
Google searches** for the fragrance category. This is a **coverage heuristic**
(probe what people likely ask), **not a volume-equivalence** (engine query mix
skews longer/comparative/decision-stage). Volume comes from Section-4
search-interest surfaces; the engine probe supplies the **surfacing** read.

## 6. Core vs satellite architecture — the wall (seed determines layer)

- **Core** — blind, **category-seeded** search-interest + AEO surfacing read →
  **gate-facing** (Decision A), attention-class.
- **Satellite** — **first-party-seeded** (the brand's converting long-tail
  queries → AEO visibility audit) → **channel-position** (Decision B): "for the
  queries that actually convert for you, is the AI showing you or a competitor?"

**The wall: the seed determines the layer.** A first-party seed is conditioned
on the brand's own data, so its result can never be an independent
demand-*existence* read — it answers channel position, not demand. The negative
case ("demand proven by conversions, but the AI doesn't surface them") is a
**visibility/risk** signal, not a demand signal. First-party-seeded results must
never launder into the blind gate read.

## 7. Gate-read delta (the required delta; Core only)

How a Core (blind) search-interest / AEO observation enters the gate:

- **Schema mapping** — populate the scan-core candidate-observation schema,
  incl. the **per-observation gate-family field** (so the two-card-set is
  mechanically checkable), plus integrity/manipulability markers and the
  `derived_from` / coordination inputs for de-correlation.
- **De-correlation** — a branded-campaign search spike or coordinated AEO
  surfacing = **one origin**, not independent demand. Because AEO origination is
  **un-verifiable** (we cannot see GEO/AEO spend), AEO surfacing is placed at
  **G4 corroboration / attention** — never an independent **G1** demand-origin.
  Search-interest may be a G1 demand-family interest signal subject to the same
  de-correlation.
- **Floor/ceiling** — both signals **cap the ceiling**, never clear the floor;
  the divergence/defeater hooks from the gate apply (manufactured pattern →
  defeats, not just caps).
- **Weighting deferred** — consistent with the frozen no-scoring-engine rule,
  this spec **defines and places** the signal and supplies the integrity /
  de-correlation / divergence markers; the **qualitative weight is the judgment
  spine's in-session job.** No numeric weights are baked here.

## 8. Reconciliation note (consume-not-fork)

This spec **consumes** the durability search-interest capture profile (capture
obligations, temporal regimes, cold-start, comparability), the envelope-delta,
and the obligation contract. It **adds**: the gate-read delta (Section 7), the
AEO surface (Sections 4/6), and the core/satellite wall (Section 6). Single home
per fact: the **durability profile** serves durability-*monitoring*; **this
delta** serves gate-*admission*; no capture obligation is duplicated. If the
durability profile already satisfies a capture obligation, this spec cites it and
adds only the read-delta.

## 9. Phase 0 — AI-Overview feasibility/automatability gate (FIRST; gates the rest)

Before any sourcing recommendation is actionable, the lane must **prove the
AI-Overview observation is feasible and automatable**:

- Can the surfaced brands/products + cited sources (+ issued queries, if visible)
  be **reliably captured** for a fragrance query set (US, logged-out, dated)?
- Is it **automatable** at a human-rate, ToS-respecting cadence, or only
  manual/one-off? What breaks it (bot detection, DOM/Overview volatility, "not
  shown" rate)?
- Output: a GO / RE-ROUTE verdict. **If AI-Overview capture is not feasible or
  not automatable, AEO-primary re-routes** (e.g., Gemini/ChatGPT become primary,
  or AEO drops to manual-spot-check) before the rest of the plan is committed.

Phase 0 is the lane's first deliverable; Sections 4–7 are contingent on its GO.

## 10. Open empirical / ROI gate (deep-research → owner sourcing-authorization)

Two empirical questions are **OPEN** and gate the owner's **sourcing
authorization (AR-04)**, not this spec:

- Do AI-answer mentions actually **convert** (vs. classic search)?
- Is **GEO/AEO efficacy** a proven revenue driver, or vendor-claimed?

AEO-surface value is **ROI-contingent** on these. Recommendation: run a focused
deep-research pass as the **input to the AEO sourcing go/no-go**; it does not
block writing or using this spec for design.

## 11. Owner-gated sourcing authorization ask

After Phase 0 GO: the lane returns a concrete recommendation — which
search-interest source(s) to source, AEO-primary engine, and the access/ToS
posture per the access-boundary decision — plus the open ROI question, for the
**owner to authorize sourcing (AR-04)**. The lane does **not** authorize
sourcing or run capture itself.

## Non-claims

Method/decision-prep only — no validation, readiness, proof, buyer-proof,
sourcing authorization, capture authorization, or implementation authorization.
The deliverable is PROPOSED until owner word and Phase-0 GO. Mentions ≠ demand;
first-party seed never enters the blind gate; deep-research efficacy is OPEN.
`model_lane: unbound`.
